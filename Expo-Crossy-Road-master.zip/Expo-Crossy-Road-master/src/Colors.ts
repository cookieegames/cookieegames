export default {
  blue: '#87C6FF',
};
