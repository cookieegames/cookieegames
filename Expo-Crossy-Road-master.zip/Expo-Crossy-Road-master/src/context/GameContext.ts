import { createContext } from 'react';

export default createContext({ character: 'bacon', setCharacter() {}, highscore: 0, setHighscore() {}, });
